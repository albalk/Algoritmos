#include<string>
using namespace std;

// Estructura que representa a un contacto
struct Contacto {
	long telefono;
	string nombre;
};
